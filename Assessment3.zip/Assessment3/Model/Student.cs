﻿namespace Assessment3.Model
{
    public class Student
    {
        public int StudentId { get; set; }
        public string Name { get; set; }
        public string Qualification { get; set; }
        public string Skill { get; set; }
    }
}

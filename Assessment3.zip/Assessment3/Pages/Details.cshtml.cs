using Assessment3.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Assessment3.Pages
{
    public class DetailsModel : PageModel
    {
        static List<Student> students =  new List<Student> {
                new Student { StudentId = 1, Name = "jaswanth", Qualification = "B.Tech", Skill = "C#" },
                new Student { StudentId = 2, Name = "varun", Qualification = "M.Tech", Skill = "Java" },
                new Student { StudentId = 3, Name = "murali", Qualification = "MCA", Skill = "Python" }
            };

        [BindProperty]
        public Student Student { get; set; }
        public List<Student> List
        {
          
             get { return students; }
        }
        public void OnGet()
        {
        }
        public IActionResult OnPost()
        {
            students.Add(Student);
            return RedirectToPage("details");
        }
    }
}
